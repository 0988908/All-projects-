﻿using System;

class Person
{
    public string Name { get; set; }
    public string Email { get; set; }

    public Person(string name, string email)
    {
        Name = name;
        Email = email;
        Console.WriteLine("Person Constructor Executed.");
    }

    public void DisplayBasicInfo()
    {
        Console.WriteLine($"Name: {Name}, Email: {Email}");
    }
}

class Student : Person
{
    public int StudentId { get; set; }
    public double Gpa { get; set; }

    public Student(string name, string email, int studentId, double gpa) : base(name, email)
    {
        StudentId = studentId;
        Gpa = gpa;
        Console.WriteLine("Student Constructor Executed.");
    }
}

class Employee : Person
{
    public int EmployeeId { get; set; }
    public double Salary { get; set; }

    public Employee(string name, string email, int employeeId, double salary) : base(name, email)
    {
        EmployeeId = employeeId;
        Salary = salary;
    }
}

class Teacher : Employee
{
    public string CourseName { get; set; }

    public Teacher(string name, string email, int employeeId, double salary, string courseName)
        : base(name, email, employeeId, salary)
    {
        CourseName = courseName;
        Console.WriteLine("Teacher Constructor Executed.");
    }

    public void Teach()
    {
        Console.WriteLine($"{Name} is teaching {CourseName}.");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("--- Creating Student ---");
        Student student = new Student("Ali", "ali@uni.com", 101, 3.8);
        student.DisplayBasicInfo();

        Console.WriteLine("\n--- Creating Teacher ---");
        Teacher teacher = new Teacher("Dr. Ahmed", "ahmed@uni.com", 202, 5000, "C# Programming");
        teacher.DisplayBasicInfo();
        teacher.Teach();
    }
}