﻿using System;
using System.Collections.Generic;


class Shape
{
    public virtual double CalculateArea()
    {
        return 0;
    }
}


class Circle : Shape
{
    public double Radius { get; set; }

    public Circle(double radius)
    {
        Radius = radius;
    }

    public override double CalculateArea()
    {
        return Math.PI * Radius * Radius;
    }
}

 
class Rectangle : Shape
{
    public double Width { get; set; }
    public double Height { get; set; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public override double CalculateArea()
    {
        return Width * Height;
    }
}

class Program
{
    static void Main()
    {
        
        List<Shape> shapes = new List<Shape>
        {
            new Circle(5.0),
            new Rectangle(4.0, 6.0)
        };

       
        foreach (Shape shape in shapes)
        {
            Console.WriteLine($"Runtime Type: {shape.GetType().Name}, Area: {shape.CalculateArea():F2}");
        }
    }
}