﻿using System;
using System.Collections.Generic;

class Person
{
    public string Name { get; set; }

    public Person(string name)
    {
        Name = name;
    }

    public virtual void DisplayInfo()
    {
        Console.WriteLine($"Person Name: {Name}");
    }
}

class Student : Person
{
    public int StudentId { get; set; }

    public Student(string name, int studentId) : base(name)
    {
        StudentId = studentId;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Student Name: {Name}, ID: {StudentId}");
    }
}

class Employee : Person
{
    public double Salary { get; set; }

    public Employee(string name, double salary) : base(name)
    {
        Salary = salary;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Employee Name: {Name}, Salary: {Salary}");
    }
}

class Teacher : Person
{
    public string CourseName { get; set; }

    public Teacher(string name, string courseName) : base(name)
    {
        CourseName = courseName;
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Teacher Name: {Name}, Course: {CourseName}");
    }
}

class Program
{
    // دالة تقبل Person وتقوم باستدعاء DisplayInfo
    static void PrintPersonInfo(Person person)
    {
        person.DisplayInfo();
    }

    static void Main()
    {
        // تخزين كائن من كل نوع في List<Person>
        List<Person> people = new List<Person>
        {
            new Student("Sara", 1002),
            new Employee("Khaled", 3500),
            new Teacher("Dr. Mona", "Data Structures")
        };

        // المرور عبر حلقة foreach واستخدام GetType() و DisplayInfo()
        foreach (Person p in people)
        {
            Console.WriteLine($"Runtime Type: {p.GetType().Name}");
            p.DisplayInfo();
            Console.WriteLine("-------------------");
        }

        // اختبار الدالة التي تقبل Person
        Console.WriteLine("Testing method accepting Person:");
        PrintPersonInfo(new Student("Omar", 1003));
    }
}